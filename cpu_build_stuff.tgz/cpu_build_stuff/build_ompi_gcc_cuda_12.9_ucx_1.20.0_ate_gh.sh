#!/bin/bash

# ./build_ompi_gcc_ate_gh.sh &> build_ompi_gcc_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`
# ./build_ompi_gcc_cuda_12.8_ucx_1.19.0_ate_gh.sh &> build_ompi_gcc_cuda_12.8_ucx_1.19.0_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`
# ./build_ompi_gcc_cuda_12.9_ucx_1.20.0_ate_gh.sh &> build_ompi_gcc_cuda_12.9_ucx_1.20.0_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`


set -x

#openmpi_version=5.0.8
openmpi_version=5.0.9

#ucx_version=1.18.1
#ucx_version=1.19.0
ucx_version=1.20.0

compiler=gcc
compiler_version=13.3
#compiler=nvidia
#compiler_version=25.3
#compiler_version=25.5

#hpc_sdk_cuda_version=25.3
hpc_sdk_cuda_version=25.11

#nvhpc_version=25.3
nvhpc_version=25.11

#cuda_version=12.8
cuda_version=12.9

#hpcx_version=2.22.1
hpcx_version=2.25.1

#ml hpc_sdk/cuda-12.8/nvhpc-hpcx-2.20-cuda12/25.3
#ml $HOME/projects/nvidia/modulefiles/nvhpc-hpcx-cuda12/25.5
#ml $HOME/projects/nvidia/modulefiles/nvhpc-byo-compiler/25.3
#ml openmpi/5.0.8/gcc_13.3/cuda_12.8
#ml openmpi/5.0.8/cuda_12.8/nvidia_25.3
#ml openmpi/5.0.8/cuda_${cuda_version}/nvidia_${compiler_version}
#ml openmpi/5.0.8/cuda_${cuda_version}/${compiler}_${compiler_version}
ml

echo LIBRARY_PATH=$LIBRARY_PATH
export LIBRARY_PATH=$HOME/projects/binutils/binutils-2.44_gcc_13.3/libiberty:$LIBRARY_PATH
#export LIBRARY_PATH=$HOME/projects/binutils/binutils-2.44_nvidia_25.5/libiberty:$LIBRARY_PATH
echo LIBRARY_PATH=$LIBRARY_PATH

# hack to avoid build error:
# In file included from ../../../../../ompi/mca/coll/hcoll/coll_hcoll_module.c:18:
# ../../../../../ompi/mca/coll/hcoll/coll_hcoll.h:30:10: fatal error: hcoll/api/hcoll_api.h: No such file or directory
echo CPATH=$CPATH
echo LD_LIBRARY_PATH=$LD_LIBRARY_PATH
#export CPATH=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/comm_libs/12.8/hpcx/hpcx-2.22.1/hcoll/include/hcoll/api:$CPATH
#export CPATH=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${compiler_version}/comm_libs/${cuda_version}/hpcx/hpcx-2.22.1/hcoll/include/hcoll/api:$CPATH

export PATH=/home/ptlin/projects/ucx/install/ucx_${ucx_version}/cuda_${cuda_version}/gcc_13.3/bin:$PATH
#export PATH=/home/ptlin/projects/ucx/install/ucx-${ucx_version}/cuda_${cuda_version}/gcc_13.3_100gb/bin:$PATH

#export LD_LIBRARY_PATH=/home/ptlin/projects/ucx/install/ucx-${ucx_version}/cuda_${cuda_version}/gcc_13.3/lib:/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${nvhpc_version}/comm_libs/${cuda_version}/hpcx/hpcx-${hpcx_version}/hcoll/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/home/ptlin/projects/ucx/install/ucx_${ucx_version}/cuda_${cuda_version}/gcc_13.3_100gb/lib:/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${nvhpc_version}/comm_libs/${cuda_version}/hpcx/hpcx-${hpcx_version}/hcoll/lib:$LD_LIBRARY_PATH

#export CPATH=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${hpc_sdk_cuda_version}/comm_libs/${cuda_version}/hpcx/hpcx-2.22.1/hcoll/include/hcoll/api:$CPATH
export CPATH=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${nvhpc_version}/comm_libs/${cuda_version}/hpcx/hpcx-${hpcx_version}/hcoll/include/hcoll/api:$CPATH

#export LD_LIBRARY_PATH=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/comm_libs/12.8/hpcx/hpcx-2.22.1/hcoll/lib:$LD_LIBRARY_PATH
echo CPATH=$CPATH
echo LD_LIBRARY_PATH=$LD_LIBRARY_PATH

#build_dir=build_cuda${cuda_version}_${compiler}${compiler_version}_ucx_${ucx_version}
build_dir=build_cuda${cuda_version}_${compiler}${compiler_version}_ucx_${ucx_version}_100gb

mkdir ${build_dir}
cd ${build_dir}

#install_dir=/software/aarch64/openmpi/openmpi${openmpi_version}/gcc_13.3/cuda_12.8

#install_dir=/software/aarch64/openmpi/openmpi_${openmpi_version}/cuda_12.8/nvidia_25.3
#install_dir=/software/aarch64/openmpi/openmpi_${openmpi_version}/cuda_${cuda_version}/${compiler}_${compiler_version}
#install_dir=/software/aarch64/openmpi/openmpi_${openmpi_version}/cuda_${cuda_version}/${compiler}_${compiler_version}/ucx_${ucx_version}
#install_dir=/home/ptlin/projects/openmpi/install/openmpi_${openmpi_version}/cuda_${cuda_version}/${compiler}_${compiler_version}/ucx_${ucx_version}

install_dir=/software/aarch64/openmpi/openmpi_${openmpi_version}/ucx_${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}

#install_dir=/home/ptlin/projects/openmpi/install/openmpi_${openmpi_version}/cuda_${cuda_version}/${compiler}_${compiler_version}/ucx_${ucx_version}_100gb

#cuda_dir=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/cuda/12.8
#cuda_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${compiler_version}/cuda/${cuda_version}
cuda_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${hpc_sdk_cuda_version}/cuda/${cuda_version}

#libcuda_dir=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/cuda/12.8/compat
libcuda_dir=${cuda_dir}/compat
#libcuda_dir=/usr/lib/aarch64-linux-gnu
#ucx_dir=/software/aarch64/ucx/ucx_1.18.1/gcc_13.3/cuda_12.8

#ucx_dir=/software/aarch64/ucx/ucx_1.18.1/cuda_12.8/nvidia_25.3
#ucx_dir=/software/aarch64/ucx/ucx_1.18.1/cuda_${cuda_version}/${compiler}_${compiler_version}
#ucx_dir=/home/ptlin/projects/ucx/install/ucx-${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}

#ucx_dir=/home/ptlin/projects/ucx/install/ucx-${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}_100gb

ucx_dir=/software/aarch64/ucx/ucx_${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}

#hcoll_dir=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/comm_libs/12.8/hpcx/hpcx-2.22.1/hcoll
#hcoll_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${compiler_version}/comm_libs/${cuda_version}/hpcx/hpcx-2.22.1/hcoll
#hcoll_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${hpc_sdk_cuda_version}/comm_libs/${cuda_version}/hpcx/hpcx-2.22.1/hcoll
hcoll_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${nvhpc_version}/comm_libs/${cuda_version}/hpcx/hpcx-${hpcx_version}/hcoll

#./configure --prefix=$HOME/local/openmpi/openmpi_4.1.7_gcc_13.2.0 CXX=g++ CC=gcc FC=gfortran

#../configure --prefix=$HOME/openmpi/install/openmpi${openmpi_version}_${compiler}${compiler_version} CXX=nvc++ CC=nvc FC=nvfortran --enable-orterun-prefix-by-default --with-cuda=/home/ptlin/projects/nvidia/Linux_aarch64/25.5/cuda --with-cuda-libdir=/usr/lib/aarch64-linux-gnu --with-ofi=no --with-ucx=$HOME/projects/ucx/install/ucx${ucx_version}/nvidia_25.5_cuda_12.9 --enable-mpi1-compatibility --disable-sphinx --with-pmix=internal --with-gpfs=no

#../configure --prefix=$HOME/projects/openmpi/install/openmpi${openmpi_version}/gcc_13.3_cuda_12.8 CXX=g++ CC=gcc FC=gfortran --enable-orterun-prefix-by-default --with-cuda=/home/ptlin/projects/nvidia/Linux_aarch64/25.3/cuda --with-cuda-libdir=/usr/lib/aarch64-linux-gnu --with-ofi=no --with-ucx=$HOME/projects/ucx/install/ucx-1.18.1/gcc_13.3_cuda_12.8 --enable-mpi1-compatibility --disable-sphinx --with-pmix=internal --with-gpfs=no

#../configure --prefix=$HOME/projects/openmpi/install/openmpi${openmpi_version}/gcc_13.3_cuda_12.8 CXX=g++ CC=gcc FC=gfortran --enable-mpi1-compatibility --with-libevent=internal --with-ucx=/home/ptlin/projects/ucx/install/ucx-1.18.1/gcc_13.3_cuda_12.8 --with-ucx-libdir=/home/ptlin/projects/ucx/install/ucx-1.18.1/gcc_13.3_cuda_12.8/lib --with-hcoll=/home/ptlin/projects/nvidia/Linux_aarch64/25.3/comm_libs/12.8/hpcx/hpcx-2.22.1/hcoll --enable-mpirun-prefix-by-default --enable-mca-dso --with-pmix --without-cray-xpmem LDFLAGS=-Wl,--enable-new-dtags 

#../configure --prefix=${install_dir} CXX=g++ CC=gcc FC=gfortran --enable-mpi1-compatibility --with-libevent=internal --with-ucx=${ucx_dir} --with-ucx-libdir=${ucx_dir}/lib --with-hcoll=${hcoll_dir} --enable-mpirun-prefix-by-default --enable-mca-dso --with-pmix --without-cray-xpmem LDFLAGS=-Wl,--enable-new-dtags

#../configure --prefix=${install_dir} CXX=g++ CC=gcc FC=gfortran --enable-mpi1-compatibility --with-libevent=internal --with-ucx=${ucx_dir} --with-ucx-libdir=${ucx_dir}/lib --with-cuda=${cuda_dir} --with-cuda-libdir=${libcuda_dir} --with-hcoll=${hcoll_dir} --enable-mpirun-prefix-by-default --with-slurm --enable-mca-dso --with-pmix --without-cray-xpmem LDFLAGS=-Wl,--enable-new-dtags
#

../configure --prefix=${install_dir} CXX=g++ CC=gcc FC=gfortran --enable-mpi1-compatibility --with-libevent=internal --with-ucx=${ucx_dir} --with-ucx-libdir=${ucx_dir}/lib --with-cuda=${cuda_dir} --with-cuda-libdir=${libcuda_dir} --with-hcoll=${hcoll_dir} --enable-mpirun-prefix-by-default --with-slurm --enable-mca-dso --with-pmix --without-cray-xpmem LDFLAGS=-Wl,--enable-new-dtags

j=64
make -j ${j} V=1 all

make install

