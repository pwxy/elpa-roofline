#!/bin/bash

ml openmpi/5.0.8/gcc_13.3/cuda_12.8
#ml openmpi/5.0.9/ucx_1.20.0/cuda_12.9/gcc_13.3

set -x 

ml

which mpicc

mpi4py_version=4.1.1

pip list

if [[ -z "${N10_TOAST3}" ]]; then
  echo "The N10_TOAST3 environment variable must be set before running install_dep.sh"
  echo "Did you remember to `source toast_env.sh` ?"
  exit
fi

# installing mpi4py, use your native MPI to install mpi4py
# for many MPI implementations, MPICC should be set to mpicc
# for cray-mpi (as used on Perlmutter), MPICC should be set to cc
if [ -z "$PE_ENV" ]; then
  #generic MPI
  MPICC=mpicc
else
  #cray MPI
  MPICC=cc
fi
#MPICC="$MPICC -shared" pip install --force-reinstall --no-cache-dir --no-binary=mpi4py mpi4py==3.1.4
MPICC="$MPICC -shared" pip install --force-reinstall --no-cache-dir --no-binary=mpi4py mpi4py==${mpi4py_version} -v

# installing H5py with parallel support, use your native MPI to install H5py
# for many MPI implementations, CC should be set to mpicc
# for cray-mpi (as used on Perlmutter), CC should be set to cc
HDF5_DIR=$N10_TOAST3/install HDF5_MPI="ON" CC=mpicc pip install --no-binary=h5py h5py==3.7.0

#Cython must be installed/updated before numpy
pip install Cython==0.29.33

# installing NumPy
# Conventional pip installs of NumPy are susceptible to ABI incompatibilies with some BLAS libraries.
# `pip install numpy==<version>` should not be used unless you are sure that
# the upstream numpy uses the same integer-width as your preferred BLAS library.
# Otherwise, numpy should be installed from source to use the matching integer-width.
# Make sure to uninstall any numpy package before attempting to install from source.
# `sh numpy_install.sh` will install numpy from source 
#  and link it against BLAS library available in $N10_TOAST3/toast3/lib
#
#pip install numpy==1.23.5
${N10_TOAST3}/build_scripts/numpy_install.sh

# Install python interface for libmadam.
# This could not be run before because of numpy dependency.
libm_dir="libmadam-1.0.2"
cd ${N10_TOAST3}/install/build/${libm_dir}/python
python setup.py install
cd ${N10_TOAST3}

# installing required python packages
#(make sure the toast3 env is activated when these and other python packages are installed)
# numpy / h5py / mpi4py should have been installed above, but are repeated here to prevent overwriting it with a newer version
pip install \
  mpi4py==${mpi4py_version} \
  h5py==3.7.0 \
  numpy==1.23.5 \
  tomlkit==0.11.4 \
  scipy==1.10.0 \
  matplotlib==3.6.3 \
  astropy==6.0.1 \
  healpy==1.17.3 \
  ephem==4.1.3 \
  pshmem==1.1.0 \
  traitlets==5.3.0 \
  psutil==5.9.1 \
  pixell==0.28.0
