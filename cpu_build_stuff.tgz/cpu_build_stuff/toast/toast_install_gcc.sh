#!/bin/bash

set -x

pip list

if [[ -z "${N10_TOAST3}" ]]; then
  echo "The N10_TOAST3 environment variable should be set before running  toast_install.sh"
  echo "Did you remember to `source toast_env.sh` ?"
  return
fi


PREFIX=${N10_TOAST3}/install
BUILD=${PREFIX}/build

BLAS="${PREFIX}/lib/libopenblas.so"
LAPACK="${PREFIX}/lib/libopenblas.so"
FFTW_ROOT="${PREFIX}"
AATM_ROOT="${PREFIX}"
SUITESPARSE_ROOT="${PREFIX}"

# Clone TOAST3
cd ${BUILD}
git clone --single-branch --branch toast3 https://github.com/hpc4cmb/toast.git TOAST3
cd TOAST3
git checkout 0992fe001cf20378204d835e9fa99b36c99ec181
mkdir build
cd build

cmake \
    -DCMAKE_C_COMPILER="gcc" \
    -DCMAKE_CXX_COMPILER="g++" \
    -DCMAKE_C_FLAGS="-O3 -g -fPIC -pthread" \
    -DCMAKE_CXX_FLAGS="-O3 -g -fPIC -pthread" \
    -DCMAKE_SHARED_LINKER_FLAGS="-lgfortran" \
    -DCMAKE_EXE_LINKER_FLAGS="-lgfortran" \
    -DCMAKE_MODULE_LINKER_FLAGS="-lgfortran" \
    -DPYTHON_EXECUTABLE:FILEPATH=$(which python3) \
    -DCMAKE_VERBOSE_MAKEFILE:BOOL=ON \
    -DTOAST_STATIC_DEPS:BOOL=ON \
    -DBLAS_LIBRARIES="${BLAS}" \
    -DLAPACK_LIBRARIES="${LAPACK}" \
    -DAATM_ROOT="${AATM_ROOT}" \
    -DFFTW_ROOT="${FFTW_ROOT}" \
    -DFFTW_LIB="${FFTW_ROOT}/lib" \
    -DFFTW_DOUBLE_LIB="${FFTW_ROOT}/lib/libfftw3.so" \
    -DMETIS_LIBRARY="${FFTW_ROOT}/lib/libmetis.so" \
    -DSUITESPARSE_INCLUDE_DIR_HINTS="${SUITESPARSE_ROOT}/include" \
    -DSUITESPARSE_LIBRARY_DIR_HINTS="${SUITESPARSE_ROOT}/lib" \
    -DCMAKE_INSTALL_PREFIX="${PREFIX}" \
    ..
    
#make -j8 install
time make -j64 install V=1

