#!/bin/bash
#
# This script installs some compiled dependencies needed by TOAST.  You should edit
# the values in this script to match your system and what dependencies you would like
# to build from scratch.
#
# See the README for more details.
#

# Install prefix
#==============================

if [[ -z "${N10_TOAST3}" ]]; then
  echo "The N10_TOAST3 environment variable should be set before running  install_dep.sh"
  echo "Did you remember to `source toast_env.sh` ?"
  return
fi

ml openmpi/5.0.9/ucx_1.20.0/cuda_12.9/gcc_13.3

set -x

ml

PREFIX=${N10_TOAST3}/install
mkdir ${PREFIX}

BUILD=${PREFIX}/build
mkdir ${BUILD}

# Serial compilers
#==============================

# Example for the GNU compilers:
CC="gcc"
CXX="g++"
FC="gfortran"

# Example for the Intel compilers:
# CC="${INTEL_PATH}/linux/bin/intel64/icc"
# CXX="${INTEL_PATH}/linux/bin/intel64/icpc"
# FC="${INTEL_PATH}/linux/bin/intel64/ifort"

# Example for OSX with clang (fortran disabled):
# CC="clang"
# CXX="clang++"
# FC=

# Compile flags
#==============================

# Example for GNU compilers
CFLAGS="-O3 -fPIC -pthread"
CXXFLAGS="-O3 -fPIC -pthread -std=c++11"
FCFLAGS="-O3 -fPIC -pthread"
OPENMP_CFLAGS="-fopenmp"
OPENMP_CXXFLAGS="-fopenmp"
LDFLAGS="-lpthread -fopenmp"

# MPI wrappers
#MPI_CC=$(which cc)
#MPI_CXX=$(which CC)

MPI_CC=$(which mpicc)
MPI_CXX=$(which mpicxx)

# Example for Intel compilers, building "fat" binaries that have object code for both
# ivybridge and newer processors as well as KNL with AVX512.
# CFLAGS="-O3 -g -fPIC -xcore-avx2 -axmic-avx512 -pthread"
# CXXFLAGS="-O3 -g -fPIC -xcore-avx2 -axmic-avx512 -pthread -std=c++11"
# FCFLAGS="-O3 -g -fPIC -xcore-avx2 -axmic-avx512 -fexceptions -pthread -heap-arrays 16"
# OPENMP_CFLAGS="-qopenmp"
# OPENMP_CXXFLAGS="-qopenmp"
# LDFLAGS="-lpthread -liomp5"

# Parallel builds
#MAKEJ=8
MAKEJ=64


# PACKAGES
#==============================

# For each of the packages below, you can either tweak the build command or comment out
# the lines completely if you are using some external package.

# GMP / MPFR
#---------------------
# Most Linux systems already have these development libraries installed (needed by
# SuiteSparse below).  They are commented out here by default.  If you are installing
# on a truly bare-bones system or in a container you may need to install these from
# scratch with your custom compilers.

# libgmp
build_libgmp=1
if [[ $build_libgmp -eq 1 ]]; then

  cd ${BUILD}
  gmp_version=6.2.0
  gmp_dir=gmp-${gmp_version}
  gmp_pkg=${gmp_dir}.tar.xz
  
  echo "Fetching libgmp"
  
  if [ ! -e ${gmp_pkg} ]; then
      curl -SL https://ftp.gnu.org/gnu/gmp/${gmp_pkg} -o ${gmp_pkg}
  fi
  
  echo "Building libgmp..."

  rm -rf ${gmp_dir}
  tar xf ${gmp_pkg}
  cd ${gmp_dir}
  CC="${CC}" CFLAGS="${CFLAGS}" ./configure --disable-static --enable-shared --with-pic --prefix="${PREFIX}" 
  make -j ${MAKEJ}
  make install

fi #[[ build_libgmp ]]

# libmpfr
build_libmpfr=1
if [[ $build_libmpfr -eq 1 ]]; then

  cd ${BUILD}
  mpfr_version=4.1.0
  mpfr_dir=mpfr-${mpfr_version}
  mpfr_pkg=${mpfr_dir}.tar.xz
  
  echo "Fetching libmpfr"
  if [ ! -e ${mpfr_pkg} ]; then
    curl -SL https://www.mpfr.org/mpfr-${mpfr_version}/${mpfr_pkg} -o ${mpfr_pkg}
  fi

  echo "Building libmpfr..."

  rm -rf ${mpfr_dir}
  tar xf ${mpfr_pkg}
  cd ${mpfr_dir}
  CC="${CC}" CFLAGS="${CFLAGS}" ./configure --disable-static --enable-shared --with-pic --with-gmp="${PREFIX}" --prefix="${PREFIX}" 
  make -j ${MAKEJ} 
  make install

fi #[[ build_mpfr ]]

# BLAS / LAPACK
#---------------------
build_openblas=1
if [[ $build_openblas -eq 1 ]]; then
  # Here we install OpenBLAS by default, but you might use any BLAS / LAPACK implementation. 
  # Install Openblas
  
  cd ${BUILD}
  openblas_version=0.3.19
  openblas_dir=OpenBLAS-${openblas_version}
  openblas_pkg=${openblas_dir}.tar.gz
  
  echo "Fetching OpenBLAS..."
  
  if [ ! -e ${openblas_pkg} ]; then
      curl -SL https://github.com/xianyi/OpenBLAS/archive/v${openblas_version}.tar.gz -o ${openblas_pkg}
  fi
  
  echo "Building OpenBLAS..."
  # export OMP_NUM_THREADS=4
  
  rm -rf ${openblas_dir}
  tar xzf ${openblas_pkg} 
  cd ${openblas_dir}
  make USE_OPENMP=1 NO_SHARED=0 MAKE_NB_JOBS=${MAKEJ}  CC="${CC}" FC="${FC}" DYNAMIC_ARCH=1 COMMON_OPT="${CFLAGS}" FCOMMON_OPT="${FCFLAGS}" LDFLAGS="${LDFLAGS}" 
  make NO_SHARED=0 PREFIX="${PREFIX}" install

fi #[[ build_openblas ]]

# If you commented out the above installation of OpenBLAS, set these lines to the
# link command for BLAS and LAPACK for use by future dependencies below.
BLAS="-L${PREFIX}/lib -lopenblas -lm ${LDFLAGS}"
LAPACK="-L${PREFIX}/lib -lopenblas -lm ${LDFLAGS}"

# Example:  Use MKL instead (and comment out the install of OpenBLAS above)
# BLAS="-L${MKLROOT}/lib/intel64 -lmkl_rt -lm ${LDFLAGS} -ldl"
# LAPACK="-L${MKLROOT}/lib/intel64 -lmkl_rt -lm ${LDFLAGS} -ldl"

# FFTW
#---------------------
build_fftw=1
if [[ $build_fftw=1 ]]; then
  
  cd ${BUILD}
  fftw_version=3.3.10
  fftw_dir=fftw-${fftw_version}
  fftw_pkg=${fftw_dir}.tar.gz
  
  echo "Fetching FFTW..."
  if [ ! -e ${fftw_pkg} ]; then
    curl -SL http://www.fftw.org/${fftw_pkg} -o ${fftw_pkg}
  fi

  echo "Building FFTW..."
  rm -rf ${fftw_dir}
  tar xzf ${fftw_pkg}
  cd ${fftw_dir}
  CC="${CC}" CFLAGS="${CFLAGS}" ./configure --enable-threads --disable-static  --enable-shared --enable-openmp --prefix="${PREFIX}"
  make -j ${MAKEJ} 
  make install

fi #[[ build_fftw ]]

# # libaatm
# # ---------------------
build_libaatm=1
if [[ $build_libaatm=1 ]]; then

  cd ${BUILD}
  aatm_version=1.0.9
  aatm_dir=libaatm-${aatm_version}
  aatm_pkg=${aatm_dir}.tar.gz
  
  echo "Fetching libaatm..."
  if [ ! -e ${aatm_pkg} ]; then
    curl -SL "https://github.com/hpc4cmb/libaatm/archive/${aatm_version}.tar.gz" -o "${aatm_pkg}"
  fi

  echo "Building libaatm..."
  rm -rf ${aatm_dir}
  tar xzf ${aatm_pkg}
  cd ${aatm_dir} 
  mkdir -p build 
  cd build
  cmake -DCMAKE_C_COMPILER="${CC}" -DCMAKE_CXX_COMPILER="${CXX}" -DCMAKE_C_FLAGS="${CFLAGS}" -DCMAKE_CXX_FLAGS="${CXXFLAGS}" -DCMAKE_VERBOSE_MAKEFILE:BOOL=ON -DCMAKE_INSTALL_PREFIX="${PREFIX}" ../
  make -j ${MAKEJ} install

fi #[[ build_libaatm ]]

# SuiteSparse
# ---------------------
build_suitesparse=1
if [[ $build_suitesparse -eq 1 ]]; then
  
  cd ${BUILD}
  ssparse_version=5.12.0
  ssparse_dir=SuiteSparse-${ssparse_version}
  ssparse_pkg=${ssparse_dir}.tar.gz
  
  echo "Fetching SuiteSparse..."

  if [ ! -e ${ssparse_pkg} ]; then
      curl -SL https://github.com/DrTimothyAldenDavis/SuiteSparse/archive/v${ssparse_version}.tar.gz -o ${ssparse_pkg}
  fi

  echo "Building SuiteSparse..."

  rm -rf ${ssparse_dir}
  tar xzf ${ssparse_pkg}
  cd ${ssparse_dir}
  sed -i "23 i TOAST_PATH = ${PREFIX}" SLIP_LU/Lib/Makefile
  sed -i 's+-lsuitesparseconfig -lamd -lcolamd -lm -lgmp -lmpfr+-L${TOAST_PATH}/lib -lsuitesparseconfig -lamd -lcolamd -lm -lgmp -lmpfr+g' SLIP_LU/Lib/Makefile
  sed -i 's+-I../Include -I../../COLAMD/Include -I../../AMD/Include -I../../SuiteSparse_config+-I../Include -I../../COLAMD/Include -I../../AMD/Include -I../../SuiteSparse_config -I${TOAST_PATH}/include+g' SLIP_LU/Lib/Makefile

  make library JOBS=${MAKEJ} CC="${CC}" CXX="${CXX}" CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" AUTOCC=no GPU_CONFIG="" CFOPENMP="${OPENMP_CXXFLAGS}" LAPACK="${LAPACK}" BLAS="${BLAS}"
  cp -a ./include/* "${PREFIX}/include/"
  cp -a ./lib/* "${PREFIX}/lib/"
  find . -name "*.a" -exec cp -a '{}' "${PREFIX}/lib/" \;

fi #[[build_suitesparse]]

## installing optional dependencies, it is recommended that these are installed as multiple CI tests will fail in their absence. 
# libconviqt for 4PI beam convolution. (depends on cfitsio)
# libmadam for optimized destriping mapmaking.

build_cfitsio=1
if [[ $build_cfitsio -eq 1 ]]; then

  cd ${BUILD}
  cfitsio_version=3.41
  cfitsio_dir=cfitsio

  ## cfitsio version 3.41, later versions are not supported by TOAST3 and will cause complications. 
  echo "Building cfitsio..."
  rm -rf ${cfitsio_dir}
  wget https://heasarc.gsfc.nasa.gov/FTP/software/fitsio/c/cfitsio3410.tar.gz 
  tar -xzf cfitsio3410.tar.gz

  cd ${cfitsio_dir}
  MPICC="${MPI_CC}" MPICXX="${MPI_CXX}"  CC="${CC}" CXX="${CXX}" CFLAGS="${CFLAGS} -fallow-argument-mismatch" FCFLAGS="${FCFLAGS} -fallow-argument-mismatch" ./configure --disable-static --enable-shared --prefix="${PREFIX}"
  make -j ${MAKEJ}
  make install

fi #[[ build_cfitsio ]]
  
## libconviqt version 1.2.7
build_libconviqt=1
if [[ $build_libconviqt -eq 1 ]]; then

  cd ${BUILD}
  libconviqt_version=1.2.7
  libconviqt_dir=libconviqt-${libconviqt_version}
  libconviqt_pkg=${libconviqt_dir}.tar.gz

  echo "Building libconviqt..."
  rm -rf ${libconviqt_dir}
  wget https://github.com/hpc4cmb/libconviqt/releases/download/v1.2.7/libconviqt-1.2.7.tar.gz

  tar -xzf ${libconviqt_pkg}
  cd ${libconviqt_dir}
  ./autogen.sh
  MPICC="${MPI_CC}" MPICXX="${MPI_CXX}" CC="${CC}" CXX="${CXX}" ./configure --disable-static --enable-shared --with-cfitsio="${PREFIX}" --prefix="${PREFIX}"
  make -j ${MAKEJ}
  make install

fi #[[ build_libconviqt

## libmadam v1.0.2
build_libmadam=1
if [[ $build_libmadam -eq 1 ]]; then

  cd ${BUILD}
  libmadam_version=1.0.2
  libmadam_dir=libmadam-${libmadam_version}
  libmadam_pkg=v1.0.2.tar.gz
  
  echo "Building libmadam... "
  rm -rf ${libmadam_dir}
  wget https://github.com/hpc4cmb/libmadam/archive/refs/tags/v1.0.2.tar.gz

  tar -xzf ${libmadam_pkg}
  cd ${libmadam_dir}
  ./autogen.sh
  MPICC="${MPI_CC}" MPICXX="${MPI_CXX}" CC="${CC}" CXX="${CXX}" CFLAGS="${CFLAGS} -fallow-argument-mismatch" FCFLAGS="${FCFLAGS} -fallow-argument-mismatch" ./configure --disable-static --enable-shared --with-cfitsio="${PREFIX}" --with-fftw="${PREFIX}" --with-blas="${BLAS}" --prefix="${PREFIX}"
  make -j ${MAKEJ}
  make install

  # python interface setup has been moved after numpy install
  # cd python
  # python setup.py install

fi #[[ build_libmadam
  
## parallel HDF5 (required for H5py)
build_hdf5=1
if [[ $build_hdf5 -eq 1 ]]; then
  cd ${BUILD}
  hdf5_version=1.12.2
  hdf5_dir=hdf5-${hdf5_version}
  hdf5_pkg=hdf5-${hdf5_version}.tar.gz
  
  echo "Fetching HDF5..."
  wget https://hdf-wordpress-1.s3.amazonaws.com/wp-content/uploads/manual/HDF5/HDF5_1_12_2/source/${hdf5_pkg}
  
  echo "Building HDF5..."

  rm -rf ${hdf5_dir}
  tar xzf ${hdf5_pkg}
  cd ${hdf5_dir}
  CC="${MPI_CC}" ./configure --enable-parallel --prefix="${PREFIX}"

  make -j ${MAKEJ} 
  make install

fi #[[build_hdf5]


echo "
TOAST dependencies have been installed to:

${PREFIX}
"
