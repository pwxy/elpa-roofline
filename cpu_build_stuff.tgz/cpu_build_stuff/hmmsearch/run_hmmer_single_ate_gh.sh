#!/bin/bash

# hmmsearch-benchmark/benchmark$ ./run_hmmer_single_ate_gh.sh &> run_hmmer_single_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`

set -x

hmmer_version=3.4

timestamp=`date +%Y%m%d_%H_%M_%S%Z`

HMM_BENCH=../..
HMM_DATA=$HMM_BENCH/data
HMM_SEARCH=$HMM_BENCH/hmmer-${hmmer_version}/src/hpc_hmmsearch

mkdir single_${timestamp} ; cd single_${timestamp}
#cp ${0} slurm_script
ln -s $HMM_DATA .
module list

ldd ${HMM_SEARCH}

nodes=1

NCPU=72
NHWT=${NCPU}
NTASKS=1

#export OMP_NUM_THREADS=${NHWT}

out=out_${timestamp}.txt

HMM_CMD="$HMM_SEARCH \
       --cpu ${NCPU} \
       -o ${out} \
       --noali \
       data/Pfam-A.hmm \
       data/uniprot_sprot.fasta"

date_i=$(date '+%s')

#srun \
#    -N ${SLURM_JOB_NUM_NODES} \
#    -n ${NTASKS} \
#    -c ${NHWT} \
#     $HMM_CMD

# HMMsearch does not use MPI
#mpirun \
#    -N ${nodes} \
#    -n ${NTASKS} \
#     $HMM_CMD

time $HMM_CMD 

date_f=$(date '+%s')
walltime=$(( date_f - date_i ))
echo "HMMsearch_walltime: $walltime"

$HMM_BENCH/scripts/validate.py $HMM_BENCH/data/ref_output_single.txt ${out}

