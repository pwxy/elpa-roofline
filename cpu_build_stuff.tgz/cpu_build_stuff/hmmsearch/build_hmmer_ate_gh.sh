#!/bin/bash

# scripts/build_hmmer_ate_gh.sh &> build_hmmer_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`

# exit on error
set -xe

#this script should be run from the hmmsearch-benchmark directory, not scripts directory
HMMER_ROOT=$PWD
hostname
date

ml
echo

hmmer_version=3.4

# download and upack base HMMER
hmmer_tar=hmmer-${hmmer_version}.tar.gz
hmmer_dir=hmmer-${hmmer_version}
if [[ -f "$hmmer_tar" ]]; then
    echo "file $hmmer_tar in place; skipping download"
else
    wget http://eddylab.org/software/hmmer/hmmer-${hmmer_version}.tar.gz
fi
if [[ -d "$hmmer_dir" ]]; then
    echo "directory $hmmer_tar exists; skipping untar"
else
    tar -xvf hmmer-${hmmer_version}.tar.gz
fi

# configure, build, test hmmer
cd hmmer-${hmmer_version}
./configure && make && make check

# set update_hpcsrc to 1 to download the HPC file hpc_hmmsearch,
# otherwise use the existing hpc_hmmsearch file included with this repo. 
# default [0] is to use the hpc_hmmsearch contained in this repo.
update_hpcsrc=0
if [[ $update_hpcsrc -eq 1 ]]; then
    cd $HMMER_ROOT/hpc_hmmsearch
    wget https://raw.githubusercontent.com/Larofeticus/hpc_hmmsearch/master/hpc_hmmsearch.c
fi

# move into hmmer source dir and compile hpc_hmmsearch file
cd $HMMER_ROOT/$hmmer_dir/src
ln -s $HMMER_ROOT/hpc_hmmsearch/Makefile.hpc .
ln -s $HMMER_ROOT/hpc_hmmsearch/hpc_hmmsearch.c .

# hmmer-3.4 changed the name of a lib function
sed -ie 's/p7_hmmfile_OpenE/p7_hmmfile_Open/g' hpc_hmmsearch.c

make -f Makefile.hpc V=1

