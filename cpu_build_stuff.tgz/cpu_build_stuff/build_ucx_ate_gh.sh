#!/bin/bash

# ./build_ucx_ate_gh.sh &> build_ucx_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`

# ./build_ucx_ate_gh.sh &> build_ucx_1.20.0_ate_gh_out_`date +%Y%m%d_%H_%M_%S%Z`

# Use nvidia 25.5 compiler, but none of the cuda 12.9 stuff bundled with it (have to get cuda 12.8 stuff from 25.3 nvidia HPC SDK, so be careful with paths)

set -x

#ucx_version=1.16.0
#ucx_version=1.17.0
#ucx_version=1.19.0
ucx_version=1.20.0

#gcc_version=_13.2.0
compiler=gcc
compiler_version=13.3
#compiler=nvhpc
#compiler=nvidia
#compiler_version=25.3
#compiler_version=25.5

#cuda_version=12.6
#cuda_version=12.8
cuda_version=12.9

#nvhpc_version=25.1
#nvhpc_version=25.3
nvhpc_version=25.11

##ml hpc_sdk/cuda-12.8/nvhpc-hpcx-2.20-cuda12/25.3
#ml $HOME/projects/nvidia/modulefiles/nvhpc-byo-compiler/25.3
#ml openmpi/5.0.8/cuda_12.8/nvidia_25.3
#ml openmpi/5.0.8/cuda_${cuda_version}/nvidia_${compiler_version}

#ml openmpi/5.0.8/cuda_${cuda_version}/${compiler}_${compiler_version}
ml

# immediately after untar v1.18.1.tar.gz, must run autogen.sh to produce configure file
#./autogen.sh

#which nvc
#nvc --version

which gcc
gcc --version

which nvcc
nvcc --version

echo
echo CPATH=$CPATH
echo LIBRARY_PATH=$LIBRARY_PATH
echo PATH=$PATH
echo LD_LIBRARY_PATH=$LD_LIBRARY_PATH
echo

#./contrib/configure-release CXX=nvc++ CC=nvc FC=nvfortran --prefix=$HOME/projects/ucx/install/ucx${ucx_version}/nvidia${compiler_version}_cuda${cuda_version} --with-cuda=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/cuda

#./contrib/configure-release CXX=g++ CC=gcc FC=gfortran --prefix=$HOME/projects/ucx/install/ucx${ucx_version}/nvidia${compiler_version}_cuda${cuda_version} --with-cuda=/home/ptlin/projects/nvidia/Linux_aarch64/${compiler_version}/cuda

#install_dir=/software/aarch64/ucx/ucx-1.18.1/gcc_13.3/cuda_12.8
#install_dir=/software/aarch64/ucx/ucx-1.18.1/${compiler}_${compiler_version}/cuda_${cuda_version}

#install_dir=/software/aarch64/ucx/ucx-1.18.1/cuda_${cuda_version}/${compiler}_${compiler_version}
install_dir=/software/aarch64/ucx/ucx_${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}
#install_dir=/home/ptlin/projects/ucx/install/ucx-${ucx_version}/cuda_${cuda_version}/${compiler}_${compiler_version}

#cuda_dir=/software/aarch64/hpc_sdk/cuda-12.8/Linux_aarch64/25.3/cuda/12.8
#cuda_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${compiler_version}/cuda/${cuda_version}

#cuda_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/25.3/cuda/${cuda_version}
cuda_dir=/software/aarch64/hpc_sdk/cuda-${cuda_version}/Linux_aarch64/${nvhpc_version}/cuda/${cuda_version}

#./contrib/configure-release CXX=g++ CC=gcc FC=gfortran --prefix=${install_dir} --with-cuda=/home/ptlin/projects/nvidia/Linux_aarch64/25.3/cuda/12.8 --enable-compiler-opt=3 --disable-assertions --disable-logging --disable-debug --disable-params-check --with-mcpu --with-march --with-rc --with-ud --with-dc --with-dm --with-devx --with-bfd --with-mlx5 --with-ib-hw-tm --enable-tuning --enable-cma --enable-mt --enable-ucg --enable-examples --without-java --enable-static=yes --enable-shared=yes --enable-devel-headers

#./contrib/configure-release CXX=g++ CC=gcc FC=gfortran --prefix=${install_dir} --with-cuda=${cuda_dir} --enable-compiler-opt=3 --disable-assertions --disable-logging --disable-debug --disable-params-check --with-mcpu --with-march --with-rc --with-ud --with-dc --with-dm --with-devx --with-bfd --with-mlx5 --with-ib-hw-tm --enable-tuning --enable-cma --enable-mt --enable-ucg --enable-examples --without-java --enable-static=yes --enable-shared=yes --enable-devel-headers

# correct option is "--with-mlx5", there is no "--with-mlx5-dv" option

./contrib/configure-release CXX=g++ CC=gcc FC=gfortran --prefix=${install_dir} --with-cuda=${cuda_dir} --enable-optimizations --enable-compiler-opt=3 --disable-assertions --disable-logging --disable-debug --disable-params-check --with-mcpu --with-march --with-rc --with-ud --with-dc --with-dm --with-devx --with-bfd --with-mlx5 --with-ib-hw-tm --enable-tuning --enable-cma --enable-mt --enable-ucg --enable-examples --without-java --enable-static=yes --enable-shared=yes --enable-devel-headers

j=64
make -j ${j} V=1

make install

